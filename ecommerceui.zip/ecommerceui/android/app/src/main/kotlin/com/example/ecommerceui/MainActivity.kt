package com.example.ecommerceui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
